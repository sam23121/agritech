import setuptools

setuptools.setup(
    name= "lidar_pipeline",
    version='0.0.1',
    author="Samuel Anagow",
    description="a python package the easily use, load and visuliaze lidar data points",
    packages=["package_scripts"]
)

